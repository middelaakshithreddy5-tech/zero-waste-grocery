# Zero-Waste Grocery Dashboard

## Run on your computer
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this folder.
3. Open Command Prompt / Terminal inside this folder.
4. Install the libraries:
   `pip install -r requirements.txt`
5. Start the dashboard:
   `streamlit run app.py`
6. Open the local address shown in the terminal, usually http://localhost:8501.

Files:
- app.py: Streamlit dashboard
- sample_grocery_data.csv: synthetic demo inventory data
- requirements.txt: required Python packages

This is a student-project prototype. Demand and risk values are sample inputs, not live ML predictions. It does not connect to actual ERP/POS/WMS systems.
