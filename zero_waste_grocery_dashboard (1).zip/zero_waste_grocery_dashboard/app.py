import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Zero-Waste Grocery", page_icon="🥬", layout="wide")
st.title("🥬 Zero-Waste Grocery")
st.caption("Agentic AI dashboard for perishable demand, shelf-life and inventory decisions")
st.info("Prototype using synthetic sample data. Review recommendations before taking real-world action.")

DATA_PATH = Path(__file__).parent / "sample_grocery_data.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH)
    df["expiry_date"] = pd.to_datetime(df["expiry_date"])
    return df

df = load_data()
today = pd.Timestamp.today().normalize()
df["days_to_expiry"] = (df["expiry_date"] - today).dt.days
df["surplus_units"] = (df["stock_quantity"] - df["predicted_demand"]).clip(lower=0)
df["potential_waste_units"] = np.where(
    df["days_to_expiry"] <= 3, df["surplus_units"],
    np.where(df["spoilage_risk"].eq("High"), df["surplus_units"] * 0.5, 0)
)
df["potential_waste_value"] = df["potential_waste_units"] * df["unit_price"]

def recommend(r):
    if r["days_to_expiry"] <= 0:
        return "Remove / check expiry"
    if r["stock_quantity"] < r["predicted_demand"] + r["reorder_buffer"]:
        return "Replenish"
    if r["days_to_expiry"] <= 3 and r["surplus_units"] > 0:
        return "Markdown"
    if r["surplus_units"] > 10 and r["spoilage_risk"] == "High":
        return "Transfer / markdown"
    if r["surplus_units"] > 15:
        return "Review surplus"
    return "No action"

df["recommended_action"] = df.apply(recommend, axis=1)

if "decisions" not in st.session_state:
    st.session_state.decisions = {}

with st.sidebar:
    st.header("Filters")
    store = st.selectbox("Store", ["All stores"] + sorted(df["store_id"].unique()))
    category = st.selectbox("Category", ["All categories"] + sorted(df["category"].unique()))
    risks = st.multiselect("Spoilage risk", ["Low", "Medium", "High"], default=["Low", "Medium", "High"])
    action = st.selectbox("Recommended action", ["All actions"] + sorted(df["recommended_action"].unique()))

view = df.copy()
if store != "All stores":
    view = view[view["store_id"] == store]
if category != "All categories":
    view = view[view["category"] == category]
view = view[view["spoilage_risk"].isin(risks)]
if action != "All actions":
    view = view[view["recommended_action"] == action]

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Store-SKUs", len(view))
k2.metric("Units in stock", f"{int(view['stock_quantity'].sum()):,}")
k3.metric("High-risk products", int((view["spoilage_risk"] == "High").sum()))
k4.metric("Near-expiry surplus", int(((view["days_to_expiry"] <= 3) & (view["surplus_units"] > 0)).sum()))
k5.metric("Potential waste value", f"₹{view['potential_waste_value'].sum():,.0f}")

overview, review, inventory, about = st.tabs(["Overview", "Planner review", "Inventory data", "How it works"])

with overview:
    left, right = st.columns(2)
    with left:
        st.subheader("Stock vs predicted demand")
        chart = view.melt(id_vars=["product_name"], value_vars=["stock_quantity", "predicted_demand"],
                          var_name="Measure", value_name="Units")
        if not chart.empty:
            st.plotly_chart(px.bar(chart, x="product_name", y="Units", color="Measure", barmode="group"),
                            use_container_width=True)
        else:
            st.warning("No rows match the selected filters.")
    with right:
        st.subheader("Potential waste value by category")
        waste = view.groupby("category", as_index=False)["potential_waste_value"].sum()
        if not waste.empty:
            st.plotly_chart(px.pie(waste, names="category", values="potential_waste_value", hole=0.4),
                            use_container_width=True)
    st.subheader("Recommended actions")
    counts = view["recommended_action"].value_counts().rename_axis("Action").reset_index(name="Products")
    if not counts.empty:
        st.plotly_chart(px.bar(counts, x="Action", y="Products", text="Products"), use_container_width=True)
    st.subheader("Priority watchlist")
    priority = view.sort_values(["days_to_expiry", "potential_waste_value"], ascending=[True, False])
    st.dataframe(priority[["store_id", "product_name", "stock_quantity", "predicted_demand",
                           "days_to_expiry", "spoilage_risk", "recommended_action"]],
                 use_container_width=True, hide_index=True)

with review:
    st.subheader("Planner approval queue")
    st.write("Choose a decision for each product. Decisions remain available during this app session.")
    for _, r in view.sort_values("days_to_expiry").iterrows():
        with st.container(border=True):
            c1, c2, c3, c4 = st.columns([2, 1.2, 1.8, 2])
            c1.markdown(f"**{r['product_name']}**")
            c1.caption(f"{r['sku_id']} · {r['store_id']} · {r['category']}")
            c2.metric("Stock / demand", f"{int(r['stock_quantity'])} / {int(r['predicted_demand'])}")
            c3.markdown(f"**Recommendation:** {r['recommended_action']}")
            c3.caption(f"{max(0, int(r['days_to_expiry']))} days to expiry · {r['spoilage_risk']} risk")
            options = ["Pending review", "Approved", "Rejected", "Needs investigation"]
            old = st.session_state.decisions.get(r["sku_id"], "Pending review")
            choice = c4.selectbox("Planner decision", options, index=options.index(old),
                                  key=f"decision_{r['sku_id']}")
            st.session_state.decisions[r["sku_id"]] = choice
    if st.session_state.decisions:
        decisions = pd.DataFrame([{"sku_id": k, "planner_decision": v}
                                  for k, v in st.session_state.decisions.items()])
        st.download_button("Download planner decisions CSV", decisions.to_csv(index=False),
                           file_name="planner_decisions.csv", mime="text/csv")

with inventory:
    cols = ["sku_id", "store_id", "product_name", "category", "stock_quantity", "predicted_demand",
            "expiry_date", "days_to_expiry", "spoilage_risk", "unit_price", "recommended_action",
            "potential_waste_units", "potential_waste_value"]
    st.dataframe(view[cols], use_container_width=True, hide_index=True)
    st.download_button("Download filtered inventory CSV", view[cols].to_csv(index=False),
                       file_name="filtered_grocery_inventory.csv", mime="text/csv")

with about:
    st.markdown("""
    **Dashboard workflow**
    1. Load grocery inventory and expiry data from CSV.
    2. Use the sample demand forecast and spoilage-risk fields.
    3. Apply business rules to recommend replenishment, markdown, transfer/review, or no action.
    4. Let the planner approve, reject, or investigate recommendations.
    5. Export the filtered inventory and planner decisions as CSV.

    **Important:** Demand and risk values are sample inputs, not outputs from a trained ML model. Potential waste is an estimate. This prototype does not connect to live ERP, WMS, or POS systems. Expired products should not be sold.
    """)

st.caption("Student project prototype • Synthetic data • No live store integration")
